# Copyright 2024 Sony Group Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


from itertools import chain
from shutil import rmtree
import csv
import glob
import json
import numpy as np
import os
import random
import shutil
import string
import tempfile
import yaml
import zipfile

from nnabla.logger import logger
from nnabla.parameter import get_parameter_or_create
from nnabla.parameter import load_parameters
from nnabla.utils.data_source_loader import FileReader, load_image_imread
import subprocess

from nnabla_console._version import __version__

################################################################################
_job_status = {}
_outdir = '.'
random_num = 8


def utcnow_timestamp():
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).timestamp()


def status_init(args):
    global _outdir
    _outdir = args.outdir

    global _job_status
    status_json_path = os.path.join(_outdir, 'status.json')
    if os.path.exists(status_json_path):
        with open(status_json_path, 'r') as f:
            _job_status = json.load(f)
    else:
        _job_status = {
            'type': args.func.__name__.rsplit('_', 1)[0],
            'start_time': utcnow_timestamp(),
        }

    # In case of Resume, status.json and monitoring_report.yml should be conflicted, then
    # if  monitoring_report.yml is already exists, read and synchronize with it.
    monitoring_report_path = os.path.join(_outdir, 'monitoring_report.yml')
    if os.path.exists(monitoring_report_path):
        with open(monitoring_report_path, 'r') as f:
            data = yaml.load(f)
        # Because the key in monitoring_report.yml is int(epoch - 1),
        # convert it to str(epoch) as same as in status.json.
        # And calculate  best and last also.
        mon_rep = {}
        best_epoch = 0
        best_valid_error = 1.0
        last_train_error = None
        last_valid_error = None
        for k in sorted(data.keys()):
            mon_rep[str(k + 1)] = data[k]
            if 'train_error' in data[k]:
                try:
                    last_train_error = float(data[k]['train_error'])
                except:
                    # Ignore if train error in monitoring_repot is invalid.
                    pass
            if 'valid_error' in data[k]:
                try:
                    last_valid_error = float(data[k]['valid_error'])
                    if last_valid_error < best_valid_error:
                        best_epoch = k + 1
                        best_valid_error = last_valid_error
                except:
                    # Ignore if valid error in monitoring_repot is invalid.
                    pass
        _job_status['monitoring_report'] = mon_rep

        if best_epoch:
            _job_status['best'] = {
                'epoch': best_epoch,
                'valid_error': best_valid_error
            }
        else:
            _job_status['best'] = {}

        _job_status['last'] = {}
        if last_train_error is not None:
            _job_status['last']['train_error'] = last_train_error
        if last_valid_error is not None:
            _job_status['last']['valid_error'] = last_valid_error


def status_get_val(keys):
    if type(keys) is str:
        keys = keys.split('.')

    target = _job_status
    for key in keys:
        key = str(key)
        if not isinstance(target, dict) or not key in target:
            return None
        target = target[key]
    return target


def status_set_val(keys, value):
    if type(keys) is str:
        keys = keys.split('.')

    global _job_status
    if not isinstance(_job_status, dict):
        _job_status = {}

    target = _job_status
    for key in keys[:-1]:
        key = str(key)
        if not key in target or not isinstance(target[key], dict):
            target[key] = {}
        target = target[key]
    key = str(keys[-1])
    target[key] = value

    if key == 'status' and value in ['finished', 'failed']:
        current = utcnow_timestamp()
        status_set_val('end_time', current)
        if value == 'finished':
            start_time = status_get_val('start_time')
            elapsed = current - start_time
            status_set_val('time.prediction', elapsed)


def status_start_process(start_time=None):
    status_set_val('_process_start_time',
                   start_time if start_time else utcnow_timestamp())


def status_update_time_train(prediction=None):
    start_time = status_get_val('start_time')
    process_start_time = status_get_val('_process_start_time')
    if not process_start_time:
        return

    if not prediction:
        epoch_current = status_get_val('epoch.current')
        epoch_max = status_get_val('epoch.max')
        if not epoch_max:
            return  # may be not reached
        current_time = utcnow_timestamp()
        process_elapsed = current_time - process_start_time
        prediction = process_elapsed / (epoch_current / epoch_max)

    pre_elapsed = process_start_time - start_time
    status_set_val('time.prediction', prediction + pre_elapsed)


def status_update_time_forward():
    current_time = utcnow_timestamp()
    start_time = status_get_val('start_time')
    process_start_time = status_get_val('_process_start_time')
    if not process_start_time:
        return
    epoch_current = status_get_val('data.current')
    epoch_max = status_get_val('data.max')
    if not epoch_max:
        return

    pre_elapsed = process_start_time - start_time
    process_elapsed = current_time - process_start_time
    prediction = process_elapsed / (epoch_current / epoch_max)

    status_set_val('time.prediction', prediction + pre_elapsed)


def status_dump(status=None):
    if status:
        status_set_val('status', status)

    random_str = ''.join(
        [random.choice(string.ascii_letters + string.digits) for i in range(random_num)])
    with open(os.path.join(_outdir, random_str + '_status.json'), 'w') as f:
        _job_status['update_timestamp'] = utcnow_timestamp()
        f.write(json.dumps(
            {
                k: _job_status[k]
                for k in filter(lambda k: k[:1] != '_',
                                _job_status.keys())
            },
            sort_keys=True,
            indent=4,
        ))
    shutil.move(_outdir + '/' + random_str + '_status.json',
                _outdir + '/' + 'status.json')


_snapshot_seq = 0


def status_save_train_snapshot():
    tmp_dir = os.path.join(_outdir, '_tmp_')
    try:
        os.mkdir(tmp_dir)
    except OSError:
        pass  # python2 does not support exists_ok arg

    nnp_files = glob.glob(os.path.join(_outdir, '*.nnp'))
    for nnp_file in nnp_files:
        shutil.copy2(nnp_file, tmp_dir)
        shutil.copy2(nnp_file, os.path.join(tmp_dir, 'result.nnp'))

    for result_file in [
            os.path.join(_outdir, 'monitoring_report.yml'),
    ]:
        try:
            shutil.copy2(result_file, tmp_dir)
        except FileNotFoundError:
            pass

    global _snapshot_seq
    _snapshot_seq += 1
    snapshot_dir = os.path.join(_outdir, '{}_snapshot'.format(_snapshot_seq))
    while os.path.exists(snapshot_dir):
        _snapshot_seq += 1
        snapshot_dir = os.path.join(
            _outdir, '{}_snapshot'.format(_snapshot_seq))

    os.rename(tmp_dir, snapshot_dir)

################################################################################


def _get_best_param(paramlist):
    h5list = []
    bestlist = {}
    currentlist = {}
    # with newest spec best param store as 'results.nnp'
    if 'results.nnp' in paramlist:
        return 'results.nnp'
    for fn in paramlist:
        name, ext = os.path.splitext(fn)
        if ext == '.h5':
            h5.append(ext)
        elif ext == '.nnp':
            ns = name.split('_')
            if len(ns) == 3:
                if ns[0] == 'results':
                    if ns[1] == 'best':
                        bestlist[int(ns[2])] = fn
                    elif ns[1] == 'current':
                        currentlist[int(ns[2])] = fn
    if len(bestlist) > 0:
        return bestlist[sorted(bestlist.keys()).pop()]
    elif len(currentlist) > 0:
        return currentlist[sorted(currentlist.keys()).pop()]
    elif len(h5list) > 0:
        return sorted(h5list).pop()
    return None


def get_info_from_sdcproj(args):
    if args.sdcproj and args.job_url_list:
        job_url_list = {}
        with open(args.job_url_list) as f:
            for line in f.readlines():
                ls = line.strip().split()
                if len(ls) == 2:
                    job_url_list[ls[0]] = ls[1]

        param_list = {}
        if args.assign is not None:
            with open(args.assign) as f:
                for line in f.readlines():
                    ls = line.strip().split(',')
                    if len(ls) == 2:
                        src, dst = ls
                        src = src.strip()
                        dst = dst.strip()
                        job_id, param = src.split('/', 1)
                        if job_id in job_url_list:
                            uri = job_url_list[job_id]
                            if uri not in param_list:
                                param_list[uri] = {}
                            if param in param_list[uri] and param_list[uri][param] != dst:
                                logger.log(99, '{} in {} duplicated between {} and {}'.format(
                                    param, uri, dst, param_list[uri][param]))
                                sys.exit(-1)
                            param_list[uri][param] = dst

        for uri, params in param_list.items():
            param_proto = None
            param_fn = None
            if uri[0:5].lower() == 's3://':
                uri_header, uri_body = uri.split('://', 1)
                us = uri_body.split('/', 1)
                bucketname = us.pop(0)
                base_key = us[0]
                logger.info(
                    'Creating session for S3 bucket {}'.format(bucketname))
                import boto3
                bucket = boto3.session.Session().resource('s3').Bucket(bucketname)
                paramlist = []
                for obj in bucket.objects.filter(Prefix=base_key):
                    fn = obj.key[len(base_key) + 1:]
                    if len(fn) > 0:
                        paramlist.append(fn)
                p = _get_best_param(paramlist)
                if p is not None:
                    param_fn = uri + '/' + p
                    tempdir = tempfile.mkdtemp()
                    tmp = os.path.join(tempdir, p)
                    with open(tmp, 'wb') as f:
                        f.write(bucket.Object(
                            base_key + '/' + p).get()['Body'].read())
                    param_proto = load_parameters(tmp, needs_proto=True)
                    rmtree(tempdir, ignore_errors=True)

            else:
                paramlist = []
                for fn in glob.glob('{}/*'.format(uri)):
                    paramlist.append(os.path.basename(fn))
                p = _get_best_param(paramlist)
                if p is not None:
                    param_fn = os.path.join(uri, p)
                    param_proto = load_parameters(param_fn, needs_proto=True)

            if param_proto is not None:
                for param in param_proto.parameter:
                    pn = param.variable_name.replace('/', '~')
                    if pn in params:
                        dst = params[pn]
                        logger.log(99, 'Update variable {} from {}({})'.format(
                            dst, param_fn, pn))
                        var = get_parameter_or_create(dst, param.shape.dim)
                        var.d = np.reshape(param.data, param.shape.dim)
                        var.need_grad = param.need_grad

    timelimit = -1
    if args.sdcproj:
        with open(args.sdcproj) as f:
            for line in f.readlines():
                ls = line.strip().split('=')
                if len(ls) == 2:
                    var, val = ls
                    if var == 'TimeLimit' and val:
                        timelimits = [int(x) for x in val.split(':')]
                        if len(timelimits) == 4:
                            timelimit = float(timelimits[0] * 24 * 3600 +
                                              timelimits[1] * 3600 +
                                              timelimits[2] * 60 + timelimits[3])
    return timelimit


################################################################################
# callbacks

def get_callback_version():
    return __version__


def get_best_from_status(args):
    status_json_path = os.path.join(args.outdir, 'status.json')
    best_epoch = None
    best_error = None
    if os.path.exists(status_json_path):
        with open(status_json_path, 'r') as f:
            _job_status = json.load(f)
        if 'best' in _job_status:
            if _job_status['best']:
                best_error = _job_status['best']['valid_error']
                best_epoch = _job_status['best']['epoch']
    return best_error, best_epoch


def update_time_train(prediction=None):
    status_update_time_train(prediction)


def save_train_snapshot():
    status_save_train_snapshot()


def update_status(state=None, start=False, start_time=None):
    if start:
        status_start_process(start_time)
    if state is None or type(state) is str:
        status_dump(state)
    elif type(state) is tuple:
        status_set_val(*state)
    else:
        status_init(state)


def add_train_command_arg(subparser):
    subparser.add_argument(
        '-a', '--assign', help='csv file that defines parameter assignment.')
    subparser.add_argument(
        '-s', '--sdcproj', help='path to sdcproj', required=False)
    subparser.add_argument(
        '-j', '--job_url_list', help='path to job url list', required=False)
    subparser.add_argument(
        '-t', '--time_limit', help='exec time limit', required=False)


def get_timelimit(args):
    return get_info_from_sdcproj(args)


def process_evaluation_result(outdir, filename):
    filereader = FileReader(filename)
    with filereader.open(textmode=True) as f:
        rows = [row for row in csv.reader(f)]
    row0 = rows.pop(0)

    images = {}
    ref_image_num = 0
    new_rows = []
    for row in rows:
        new_row = []
        for item in row:

            isfile = False
            try:
                isfile = os.path.isfile(item)
            except:
                isfile = False

            if isfile:
                if os.path.isabs(item):
                    image_filename = item
                    image_name = './reference/{}_{}'.format(
                        ref_image_num, os.path.basename(item))
                    ref_image_num += 1
                    item = image_name
                    images[image_name] = image_filename
                else:
                    image_filename = item
                    image_name = item
                    images[image_name] = image_filename
            else:

                isfile = False
                try:
                    isfile = os.path.isfile(os.path.join(outdir, item))
                except:
                    isfile = False

                if isfile:
                    image_filename = os.path.join(outdir, item)
                    image_name = item
                    images[image_name] = image_filename

            new_row.append(item)
        new_rows.append(new_row)

    result_csv_filename_tmp = os.path.join(
        outdir, 'output_result_tmp.csv')

    with open(result_csv_filename_tmp, 'w') as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(row0)
        writer.writerows(new_rows)

    result_zip_filename = os.path.join(outdir, 'output_result.zip')
    with zipfile.ZipFile(result_zip_filename, 'w') as res:
        res.write(result_csv_filename_tmp, 'output_result.csv')
        for name, filename in images.items():
            res.write(filename, name)
    globname = os.path.join(outdir, 'result*.nnp')
    exists = glob.glob(globname)
    last_results = []
    if len(exists) > 0:
        last_result_nums = {}
        for ex in exists:
            name = os.path.basename(ex).rsplit('.', 1)[0]
            try:
                name_base, num = name.rsplit('_', 1)
                num = int(num)
                if name_base not in last_result_nums:
                    last_result_nums[name_base] = []
                last_result_nums[name_base].append(num)
            except:
                last_results.append(os.path.basename(ex))
        for base in last_result_nums.keys():
            last_results.append('{}_{}.nnp'.format(
                base, sorted(last_result_nums[base]).pop()))

    for result_filename in last_results:
        result_zip_name = 'output_result.zip'
        result_zip_num = 1
        with zipfile.ZipFile(os.path.join(outdir, result_filename), 'a') as res:
            while result_zip_name in res.namelist():
                result_zip_name = 'output_result_{}.zip'.format(result_zip_num)
                result_zip_num += 1
            logger.log(99, 'Add {} to {}.'.format(
                result_zip_name, result_filename))
            res.write(result_zip_filename, result_zip_name)


def update_forward_time():
    status_update_time_forward()


def check_training_time(args, config, timeinfo, epoch, last_epoch):
    if epoch < config.training_config.max_epoch:
        elapsed_time = timeinfo.start_time - \
            status_get_val('start_time') + \
            timeinfo.past_time
        avg_time_per_epoch = timeinfo.past_time / \
            (epoch - last_epoch)

        if args.time_limit is not None and (elapsed_time + avg_time_per_epoch) >= float(args.time_limit):
            f = open(os.path.join(
                args.outdir, 'force_restart'), 'a')
            f.write('remain_time: {}\n'.format(
                timeinfo.remain_time))
            f.close()
            return False
    return True


def result_base(base, suffix, outdir):
    if suffix is None:
        return os.path.join(outdir, 'results')
    return base


def update_progress(text):
    if text.startswith('Create cache'):
        logger.log(99, text)


def get_load_image_func(ext):
    # Left it, for possible future extension of image format.
    return None

