# Copyright 2024 Sony Group Corporation.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.


import json
import os
import re
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone

last_error = None


def line_to_error(line):
    global last_error
    m = re.match('^ValueError: c', line)
    if m:
        # 期待と異なるshapeを持つvariableが入力されました。データセットのShapeと入力Shapeが会っているか、関数の前後で異なるshapeを指定していないかを確認してください。
        return {'code': '40014000', 'message': line}
    m = re.match('^Failed \`.*\`: Size of input', line)
    if m:
        # 期待と異なるサイズを持つvariableが入力されました。データセットのサイズとネットワークの入力サイズが会っているか、関数の前後でサイズが異なっていないかを確認してください。
        return {'code': '40014001', 'message': line}

    m = re.match('^Weights must be a tensor more than 3D', line)
    if m:
        # Convolutionのパラメータを確認して下さい
        return {'code': '40014003', 'message': line}

    m = re.match('^.*needs at least', line)
    if m:
        # 関数に対する入力の数が合っていません。ネットワークを確認してください。
        return {'code': '40014004', 'message': line}

    m = re.match('^cudnn/function/./generic/max_pooling.cu:', line)
    if m:
        # poolingのパラメータを確認してください
        return {'code': '40014005', 'message': line}

    m = re.match('^cudnn/function/./generic/convolution.cu:', line)
    if m:
        # Convolutionのパラメータを確認して下さい
        return {'code': '40014006', 'message': line}

    m = re.match('^MemoryError', line)
    if m:
        # Fuctionの入出力に必要となるメモリサイズが大きすぎます
        return {'code': '40014008', 'message': line}

    m = re.match('^RuntimeError: memory error', line)
    if m:
        # パラメータが必要とするメモリサイズが大きすぎます
        return {'code': '40014009', 'message': line}

    m = re.match('^Fatal Error: INVALID CACHE', line)
    if m:
        # キャッシュファイルが異常です
        return {'code': '50018104', 'E_SDEEP_DATASET_CACHE_NOT_FOUND': line}

    m = re.match('^.*ABORTED$', line)
    if m:
        # 中断されました
        if last_error is None:
            return {'code': '40014007', 'message': line}

    return None


def finish(outdir):
    global last_error
    if last_error is not None:
        jsonpath = os.path.join(outdir, 'status.json')
        try:
            with open(jsonpath, 'r') as f:
                job_status = json.load(f)
        except:
            job_status = {}
        job_status['last_error'] = last_error
        job_status['status'] = 'aborted'
        with open(jsonpath, 'w') as f:
            job_status['update_timestamp'] = datetime.now(
                timezone.utc).timestamp()
            f.write(json.dumps(job_status, sort_keys=True, indent=4))


def output_line(line):
    global last_error
    l = line.rstrip().decode("utf8")
    err = line_to_error(l)
    if err is not None:
        last_error = err
    print(l, flush=True)


def main():
    global last_error
    name = os.path.basename(sys.argv[0])
    cmd = sys.argv[:]
    if name == 'console_cli':
        cmd[0] = 'nnabla_cli'

    outdir = '.'
    preprocess_cmd = None
    mpi_cmd = []
    if '-o' in cmd:
        pos = cmd.index('-o')
        outdir = cmd[pos+1]
    if '--output' in cmd:
        pos = cmd.index('-output')
        outdir = cmd[pos+1]
    if '--prepare' in cmd:
        pos = cmd.index('--prepare')
        preprocess_cmd = cmd[pos+1].split(' ')
        cmd.pop(pos)
        cmd.pop(pos)
    if '--multi' in cmd:
        pos = cmd.index('--multi')
        cmd.pop(pos)
        num_of_gpu = cmd.pop(pos)
        cmd.insert(1, '-m')
        if num_of_gpu.isnumeric():
            mpi_cmd = ['mpiexec', '-q', '-n', num_of_gpu]
        else:
            # it should be a hostfile
            mpi_cmd = ['mpiexec', '--hostfile', num_of_gpu]

    myenv = os.environ.copy()
    myenv["NNABLA_CONFIG_FILE_PATH"] = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'nnabla.conf')
    if preprocess_cmd:
        cmd = mpi_cmd + preprocess_cmd + [' '.join(cmd)]
        p = subprocess.Popen(cmd, bufsize=1, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, env=myenv)
    else:
        cmd = mpi_cmd + cmd
        p = subprocess.Popen(cmd, bufsize=1, stdout=subprocess.PIPE,
                             stderr=subprocess.STDOUT, env=myenv)

    _finish = False

    def _wait():
        count = 0
        while not _finish:
            if count > 100:  # 10sec
                print("STALLED", flush=True)
                finish(outdir)
                os.kill(os.getpid(), 9)
            time.sleep(0.1)
            if last_error is None:
                count = 0
            else:
                count += 1

    th = threading.Thread(target=_wait)
    th.start()

    last_error = None
    for line in iter(p.stdout.readline, b''):
        output_line(line)
    _finish = True
    th.join()

    finish(outdir)

    p.wait(5)
    sys.exit(p.returncode)


if __name__ == '__main__':
    main()
